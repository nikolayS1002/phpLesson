<?php

//Первым делом подключим файл с константами настроек
include "../config/config.php";

$url_array = explode('/', $_SERVER['REQUEST_URI']);


//Читаем параметр page из url, чтобы определить, какую страницу-шаблон
//хочет увидеть пользователь, по умолчанию это будет index
if ($url_array[1] == "") {
    $page = 'index';
} else {
    $page = $url_array[1];
}

//Для каждой страницы готовим массив со своим набором переменных
//для подстановки их в соотвествующий шаблон
$params = [
    'count' => 2,
    'menu' => getMenu(),
];

switch ($page) {
    case 'index':
        $params['name'] = 'Alex';
        break;

    case 'catalog':
        $params['catalog'] = getCatalog();
        break;

    case 'gallery':
        if (!empty($_FILES)) {
            upload();
        }
        $messages = [
            'ok' => 'Файл заружен',
            'error' => 'Ошибка загрузки'
        ];
        $params['gallery'] = getGallery();
        $params['message'] = $messages[strtolower($_GET['message'])];
        $params['images'] = getSortedImages();
        break;

    case 'imageone':
        $id = (int)$_GET['id'];
        $params['views'] = updateViews($id);
        $params['images'] = getOneImage($id);
        break;

    case 'apicatalog':
        echo json_encode(getCatalog(), JSON_UNESCAPED_UNICODE);
        die();
}

//_log($params, "render");
echo render($page, $params);
