Каталог

<?php
var_dump($catalog);