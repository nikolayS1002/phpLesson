<div>
<a rel="gallery" class="photo" href="/gallery_img/big/<?=$images['title']?>"><img src="/gallery_img/big/<?=$images['title']?>"></a>
    <div><h2>Количество просмотров: <?=$images['views']?></h2></div>
</div>