<ul>
<?php foreach ($menu as $key => $value):?>
<li><a href="<?=$key?>"><?=$value?></a></li>
 <?php endforeach;?>
 </ul><br>