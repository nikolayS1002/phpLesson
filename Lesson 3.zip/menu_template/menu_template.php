<ul>
	<li><a href='#'>Меню1</a></li>
	<li><a href='#'>Меню2</a></li>
	<li><a href='#'>Меню3</a></li>
	<li><a href='3'>Меню4</a></li>
</ul>
