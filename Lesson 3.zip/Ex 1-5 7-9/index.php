<?php

// ex 1
$n = 0;
while ($n <= 100) {
    if ($n % 3 == 0) {
        echo "{$n}, ";
    }
    $n++;
}

// ex 2
echo "<br><br>";
$m = 0;
do {

    if ($m == 0) {
        echo "{$m} - ноль<br>";
        // } elseif ($m % 2 == 0){
        // echo "{$m} - четное число<br>";
    } else {
        echo ($m % 2 == 0) ?  "{$m} - четное число<br>" : "{$m} - нечетное число<br>";
        // echo "{$m} - нечетное число<br>";
    }
    $m++;
} while ($m <= 10);

// ex 3, ex 8
echo "<br><br>";
$Towns = [
    "Московская область" => ["Москва", "Зеленоград", "Клин"],
    "Ленинградская область" => ["Санкт-Петербург", "Всеволожск", "Павловск", "Кронштадт"],
    "Рязанская область" => ["Рязань", "Касимов", "Ряжск"],
];

foreach ($Towns as $key => $item) {
    echo $key . ":<br>";
    foreach ($item as $town) {
        // if (strpos($town, "К") === 0) {  // раскомментировать для получения ex 8
        //     $str .= $town . ", ";
        // }
        $townStr .= $town . ", ";    // закомментировать для получения результата ex 8
    }
    $townStr = substr_replace($townStr, ".<br>", -2);
    echo $townStr;
    $townStr = "";
}

// ex 4
echo "<br><br>";

echo $str = "Здесь приведенА 1на строка: она НЕ проста! Она - лЮбой сложности...";
echo "<br>";
echo textTranslate($str);

function textTranslate($str){
    $alfabet = [
        'а' => 'a',   'б' => 'b',   'в' => 'v',
        'г' => 'g',   'д' => 'd',   'е' => 'e',
        'ё' => 'e',   'ж' => 'zh',  'з' => 'z',
        'и' => 'i',   'й' => 'y',   'к' => 'k',
        'л' => 'l',   'м' => 'm',   'н' => 'n',
        'о' => 'o',   'п' => 'p',   'р' => 'r',
        'с' => 's',   'т' => 't',   'у' => 'u',
        'ф' => 'f',   'х' => 'h',   'ц' => 'c',
        'ч' => 'ch',  'ш' => 'sh',  'щ' => 'sch',
        'ь' => '\'',  'ы' => 'y',   'ъ' => '\'',
        'э' => 'e',   'ю' => 'yu',  'я' => 'ya'
    ];
    $strNew = "";


    for ($i = 0; $i < mb_strlen($str); $i++) {
        $char =  mb_substr($str, $i, 1);
        $charLow = mb_strtolower($char);
        if ($charLow != $char) {
            foreach ($alfabet as $key => $item) {
                if ($charLow == $key) {
                    $strNew .= mb_strtoupper($item);
                    break;
                } elseif ($key == "я") {
                    $strNew .= $charLow;
                }
            }
        } else {
            foreach ($alfabet as $key => $item) {
                if ($charLow == $key) {
                    $strNew .= $item;

                    break;
                } elseif ($key == "я") {
                    $strNew .= $charLow;
                }
            }
        }
    }
    return $strNew;
}

// ex 5
echo "<br><br>";
echo textReplece("$str");
function textReplece($text){
    return $text = str_replace(" ", "_", $text);
}

// ex 7
echo "<br><br>";
for ($i = 0; $i < 10; print $i++){}

// ex 9
echo "<br><br>";
echo textFormat($str);
function textFormat($text) {
    $text = textReplece($text);
    return $text = textTranslate($text);
}