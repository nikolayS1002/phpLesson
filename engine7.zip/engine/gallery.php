<?php
function getGallery() {
    return [];
}